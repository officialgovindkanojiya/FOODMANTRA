<?php

include "header.php";


include "connection.php";
?>

<section class="">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 pull-right pl-60 pl-sm-15">
              
                
               
              <!-- Portfolio Gallery Grid -->
            

              <div class="gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
        
              </div>
              <!-- End Portfolio Gallery Grid -->

             

              <div class="row">
                <?php
                    $query = mysqli_query($conn,"SELECT * from orders where cemail='$email'");
                    
                ?>
               <div class="col-md-12 mb-30">
                    <strong>My Orders</strong> 
                    

                    <div class="col-md-12">
                      
                    <br><br>
                        <table class="table">
                            <tr>
                                <td><b>Item Name</b></td>
                                <td><b>Category Name</b></td>
                                <td><b>Hotel Name</b></td>
                            </tr>
                            <?php
                            while($k = mysqli_fetch_array($query))
                            {
                                $itemname = $k['item_name'];
                                $amount = $k['amount'];
                                $owneremail = $k['oemail'];
                                
                            ?>
                            <?php 
                            $query1 = mysqli_query($conn,"SELECT * from hotelregister1 where email='$owneremail'");
                            while($k1 = mysqli_fetch_array($query1)){
                               $hotelname=$k1['hotelname'];
                            }
                            ?>
                            <tr>
                               <td><?php echo $itemname; ?></td>
                            
                                <td><?php echo $amount; ?></td>
                           
                                <td><?php echo $hotelname; ?></td>
                            </tr>
                            <?php
                            }
                            ?>
                        </table>
                    </div>
                <p>
                   
                    
                </p>
                    
                
               </div>
             </div>
             
            
            
            </div>
            <div class="col-sx-12 col-sm-4 col-md-4 sidebar pull-left">
              
              <h4 class="line-bottom">Dashboard | <b><?php echo $email; ?></b></h3></h4>
              <div class="volunteer-address">
                <ul>
                  <li>
                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-book text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       <a href="orders.php">My Orders</a>
                      
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-user text-theme-colored font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="updateprofile.php">Edit Profile</a>
                      </div>
                    </div>

                    <div class="bg-light media border-bottom-theme-colored-2px p-15 mb-20">
                      <div class="media-left">
                        <i class="fa fa-sign-out font-24 mt-5"></i>
                      </div>
                      <div class="media-body">
                       
                       <a href="logout.php">Signout</a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
      </div>
    </section>
>











<?php 
include "footer.php";
?>