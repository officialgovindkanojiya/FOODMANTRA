<?php

include "header.php";
include "connection.php";
$p=mysqli_query($conn,"SELECT * FROM customer WHERE email='$email'");
while($z=mysqli_fetch_array($p)){
    $password=$z['pass'];
}
?>
?>

 <!-- Section: inner-header -->
 <!-- Start main-content -->
 <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">CHANGE PASSWORD</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-push-2">
            <div class="widget border-1px p-30">
              <h5 class="widget-title line-bottom">Change Password</h5>
              <form  action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                  <input name="currentpass" class="form-control" type="password" placeholder="Enter Current Password">
                </div>
            <div class="form-group">
                  <input name="newpass" class="form-control" type="password" placeholder="Enter New Password">
            </div>


                <div class="form-group">
                  <input type="submit" class="btn btn-primary"   class="form-control" value="change">
                </div>
                
              </form>

              
            </div>
          </div>
        </div>
      </div>
    </section> 
  </div>  

<?php
if($_POST){
    extract($_POST);
    if($password==$currentpass){
        mysqli_query($conn, " UPDATE customer
      SET pass = '$newpass' where email='$email'");
       echo "<script>alert('Profile Updated Successfully!!');</script>";
      header('location:profile.php');
     
    }else{
        echo "<script>alert('Enter Correct Current Password!!');</script>";
       
    }
}
?>



<?php
include "footer.php";
?>