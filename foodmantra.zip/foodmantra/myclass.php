<?php

class myclass{
    public $dbhost;
    public $dbuser;
    public $dbpass;
    public $dbname;
    public $con;

    function __construct($host,$user,$pass,$name)
    {
        $this->dbhost=$host;
        $this->dbuser=$user;
        $this->dbpass=$pass;
        $this->dbname=$name;
        $this->con= new PDO("mysql:host=$this->dbhost;dbname=$this->dbname", $this->dbuser, $this->dbpass);
        // echo "connection successful";
    }
    function upload_category($category)
    {
        $u=$this->con->prepare("INSERT INTO categories VALUES('','$category')");
        $u->execute();
        echo "<script>alert('Category Uploaded Successfully'); </script>";
        
    }
    function displaycategory()
    {
        $v=$this->con->prepare("SELECT * FROM categories");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }
    function hotellist()
    {
        $v=$this->con->prepare("SELECT * FROM hotelregister1 JOIN hotelregister2 WHERE hotelregister1.email=hotelregister2.email");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }

    function itemlist()
    {
        $v=$this->con->prepare("SELECT * FROM item");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }

    function customerlist()
    {
        $v=$this->con->prepare("SELECT * FROM customer");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }
    function uploaditem($category,$itemname,$itemtype,$email,$image,$amount,$itemdetails)
    {
        $u=$this->con->prepare("INSERT INTO item VALUES('','$category','$itemname','$itemtype','$email','$image','$amount','$itemdetails')");
        $u->execute();
        // echo "<script>alert('Item Uploaded Successfully'); </script>";
        
    }
    function itemlist1($email)
    {
        $v=$this->con->prepare("SELECT * FROM item WHERE email='$email'");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }
    function orderlist()
    {
        $v=$this->con->prepare("SELECT * FROM orders");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }
    function orderlist1($email)
    {
        $v=$this->con->prepare("SELECT * FROM orders where oemail='$email'");
        $v->execute();
        $row = $v->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }

}



?>