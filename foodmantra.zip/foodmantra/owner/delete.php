<?php
include "../connection.php";
?>
<?php
$id = $_GET['id'];
$type=$_GET['type'];

if($type=='category')
{

mysqli_query($conn,"DELETE FROM categories WHERE id='$id'");
header("location:categorylist.php");
}
else if($type=='course')
{
  
    mysqli_query($conn,"DELETE FROM courses WHERE id='$id'");
    header("location:courselist.php");
}
else if($type=='itemlist')
{
    mysqli_query($conn,"DELETE FROM item WHERE id='$id'");
    header("location:itemlist.php");
}
else if($type=='orderlist1'){
    mysqli_query($conn,"DELETE FROM orders WHERE id='$id'");
    header("location:orderlist.php"); 
}

?>