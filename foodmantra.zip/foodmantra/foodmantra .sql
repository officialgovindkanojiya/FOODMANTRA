-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2022 at 07:46 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodmantra`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `photo` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `total` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `photo`, `name`, `price`, `quantity`, `total`) VALUES
(6, 'folder/itemimg/images.jpg', 'Fried Rice', '160', '1', '160');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`) VALUES
(11, 'Chinese Food'),
(13, 'Indian food');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` longtext NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `address` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `phone`, `email`, `pass`, `state`, `city`, `pin`, `address`, `photo`) VALUES
(2, 'Priyanshu', '9450187455', 'prnshozha@gmail.com', '123', 'up', 'ayodhya', '224001', 'RKBK Petrol Pump Shadatganj, Near shadatganj overbridge', 'owner/folder/itemimg/01.jpg'),
(3, 'Govind', '8707041983', 'officialgovindkanojiya@gmail.com', 'abcdef', 'up', 'ayodhya', '272130', 'chhapiya khurd keshwapur harraiya basti\r\nchhapiya khurd keshwapur harraiya basti\r\nchhapiya khurd keshwapur harraiya basti', 'owner/folder/itemimg/PicsArt_11-29-01.07.54-1.jpg'),
(4, 'Atul', '9839043649', 'gk@gmail.com', '12345', 'up', 'ayodhya', '272155', 'Lakshmanpur', 'owner/folder/itemimg/atul.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `hotelregister1`
--

CREATE TABLE `hotelregister1` (
  `id` int(11) NOT NULL,
  `ownername` varchar(200) NOT NULL,
  `hotelname` varchar(200) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotelregister1`
--

INSERT INTO `hotelregister1` (`id`, `ownername`, `hotelname`, `phone`, `email`, `pass`) VALUES
(1, 'Rahul', 'Foodlover', '9450187455', 'mauryarampratap398@gmail.com', '123'),
(2, 'Rahul', 'Foodmantra', '9450187455', 'rahul@gmail.com', 'rahul');

-- --------------------------------------------------------

--
-- Table structure for table `hotelregister2`
--

CREATE TABLE `hotelregister2` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `state` varchar(40) NOT NULL,
  `city` varchar(30) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotelregister2`
--

INSERT INTO `hotelregister2` (`id`, `email`, `state`, `city`, `pin`, `address`) VALUES
(1, 'mauryarampratap398@gmail.com', 'mumbai', 'lko', '123234', 'MAMTA EDUCATIONAL ACADEMY YERTA SIKANDARPUR BASTI'),
(2, 'rahul@gmail.com', 'up', 'ayodhya', '806479', 'chhapiya khurd keshwapur harraiya basti\r\nchhapiya khurd keshwapur harraiya basti\r\nchhapiya khurd keshwapur harraiya basti');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `category_name` varchar(30) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `image` varchar(100) NOT NULL,
  `amount` varchar(5) NOT NULL,
  `about` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `category_name`, `item_name`, `item_type`, `email`, `image`, `amount`, `about`) VALUES
(5, 'Chinese Food', 'Noodles', 'Veg', 'rahul@gmail.com', 'folder/itemimg/2.jpg', '90', 'Delicious Noodles'),
(6, 'Indian food', 'Fried Rice', 'Veg', 'rahul@gmail.com', 'folder/itemimg/images.jpg', '160', 'Delicious Indian food'),
(9, 'Indian food', 'Dosa', 'Veg', 'mauryarampratap398@gmail.com', 'folder/itemimg/Masala-Dosa-500x500.jpg', '160', 'Masala dosa!!'),
(10, 'Indian food', 'Idli', 'Veg', 'mauryarampratap398@gmail.com', 'folder/itemimg/Idli.jpg', '160', 'Delicious Idli!'),
(11, 'Chinese Food', 'Burger', 'Veg', 'rahul@gmail.com', 'folder/itemimg/burger.jpg', '190', 'Delicious Chinese Burger!!\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `catergory_name` varchar(30) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `oemail` varchar(30) NOT NULL,
  `cemail` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `item_name`, `catergory_name`, `amount`, `oemail`, `cemail`, `date`) VALUES
(2, 'Noodles', 'Chinese Food', '90', 'rahul@gmail.com', 'gk@gmail.com', '2022-04-09'),
(3, 'Dosa', 'Indian food', '160', 'mauryarampratap398@gmail.com', 'gk@gmail.com', '2022-04-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotelregister1`
--
ALTER TABLE `hotelregister1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotelregister2`
--
ALTER TABLE `hotelregister2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hotelregister1`
--
ALTER TABLE `hotelregister1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hotelregister2`
--
ALTER TABLE `hotelregister2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
