<?php

include "header.php";


include "connection.php";

$id = $_GET['id'];




$query=mysqli_query($conn,"SELECT * FROM item WHERE id='$id'");
 
while($k = mysqli_fetch_array($query))
{
    
    
    $category_name = $k['category_name'];  
    $item_name = $k['item_name'];
    $item_type = $k['item_type'];
    $oemail = $k['email'];
    $image = $k['image'];
    $amount = $k['amount'];
    $about=$k['about'];


}
?>
 

  
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg3.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="title text-white text-center"><?php echo $item_name; ?></h2>
              
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="product">
              <div class="col-md-5">
                <div class="product-image">
                  <div class="zoom-gallery">
                    <a href="owner/<?php echo $image;?>" title="Title Here 1"><img src="owner/<?php echo $image;?>" alt=""></a>
                  </div>
                </div>
              </div>
              <div class="col-md-7">
                <div class="product-summary">
                  <h2 class="product-title"><?php echo $item_name; ?></h2>
                  <div class="product_review">
                    <ul class="review_text list-inline">
                      <li>
                        <div title="Rated 4.50 out of 5" class="star-rating"><span style="width: 90%;">4.50</span></div>
                      </li>
                      <li><a href="#"><span>2</span>Reviews</a></li>
                      <li><a href="#">Add reviews</a></li>
                    </ul>
                  </div>
                  <div class="price"> <del><span class="amount">165.00</span></del> <ins><span class="amount"><?php echo $amount; ?></span></ins> </div>
                  <div class="short-description">
                    <p>
                      <?php echo $about; ?>
                    </p>
                  </div>
                  
                  <div class="category"><strong>Category:</strong> <a href="#"><?php echo $category_name; ?></a></div>
                  
                  <div class="cart-form-wrapper mt-30">
                    <form enctype="multipart/form-data" method="post" class="cart">
                      <input type="hidden" value="productID" name="add-to-cart">
                      <table class="table variations no-border">
                        <tbody>
                          <tr>
                            <td class="name"><h4>Amount:</h4><h3><?php echo $amount; ?></h3></td>
                            <td class="value">
                              <div class="quantity buttons_added">
                                <input type="button" class="minus" value="-">
                                <input type="number" size="4" class="input-text qty text" title="Qty" value="1" name="quantity" min="1" step="1">
                                <input type="button" class="plus" value="+">
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <!-- <button class="single_add_to_cart_button btn btn-theme-colored" type="submit"> <a href="cart.php?id=<?php echo $id; ?>"> Add to cart</a></button> -->
                      <?php
                      if($email){
                        ?>
                      <button class="single_add_to_cart_button btn btn-theme-colored" type="submit"><a href="buy.php?id=<?php echo $id; ?>">Buy Now</button>
                      <?php
                      }
                      else{
                        ?>
                       <button class="single_add_to_cart_button btn btn-theme-colored" type="submit"><a href="customer_register.php">Buy Now</button>  
                       <?php
                      }
                      ?>
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="horizontal-tab product-tab">
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab1" data-toggle="tab">Description</a></li>
                    
                    <li><a href="#tab3" data-toggle="tab">Reviews</a></li>
                  </ul>
                  <div class="tab-content">
                    <div class="tab-pane fade in active" id="tab1">
                      <h3>Product Description</h3>
                      <p> <?php echo $about; ?></p>
                    </div>
                    
                    <div class="tab-pane fade" id="tab3">
                      <div class="reviews">
                        <ol class="commentlist">
                          <li class="comment">
                            <div class="media"> <a href="#" class="media-left"><img class="img-circle" alt="" src="https://placehold.it/75x75" width="75"></a>
                              <div class="media-body">
                                <ul class="review_text list-inline">
                                  <li>
                                    <div title="Rated 5.00 out of 5" class="star-rating"><span style="width: 100%;">5.00</span></div>
                                  </li>
                                  <li>
                                    <h5 class="media-heading meta"><span class="author">Tom Joe</span> – Mar 15, 2015:</h5>
                                  </li>
                                </ul>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat purus tempor sem molestie, sed blandit lacus posuere. Lorem ipsum dolor sit amet.</div>
                            </div>
                          </li>
                          <li class="comment">
                            <div class="media"> <a href="#" class="media-left"><img class="img-circle" alt="" src="https://placehold.it/75x75" width="75"></a>
                              <div class="media-body">
                                <ul class="review_text list-inline">
                                  <li>
                                    <div title="Rated 4.00 out of 5" class="star-rating"><span style="width: 80%;">4.00</span></div>
                                  </li>
                                  <li>
                                    <h5 class="media-heading meta"><span class="author">Mark Doe</span> – Jan 23, 2015:</h5>
                                  </li>
                                </ul>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec volutpat purus tempor sem molestie, sed blandit lacus posuere. Lorem ipsum dolor sit amet.</div>
                            </div>
                          </li>
                        </ol>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="col-md-12">
              <h3 class="line-bottom">Related Products</h3>
              <div class="row multi-row-clearfix">
                <div class="products related">
                <?php 

                 $query1=mysqli_query($conn,"SELECT * FROM item WHERE category_name='$category_name'") ;
                 while($p=mysqli_fetch_array($query1))
                 {
                 ?>
          
                  <div class="col-sm-6 col-md-3 col-lg-3 mb-sm-30">
                    <div class="product">
                      <span class="tag-sale">Sale!</span>
                      <div class="product-thumb"> 
                        <img alt="" src="owner/<?php echo $p['image'];?>" class="img-responsive img-fullwidth">
                        <div class="overlay">
                          <div class="btn-add-to-cart-wrapper">
                            <a class="btn btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="#">Add To Cart</a>
                          </div>
                          <div class="btn-product-view-details">
                            <a class="btn btn-default btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="#">View detail</a>
                          </div>
                        </div>
                      </div>
                      <div class="product-details text-center">
                        <a href="#"><h5 class="product-title"><?php echo $p['item_name'];?></h5></a>
                        <div class="star-rating" title="Rated 3.50 out of 5"><span style="width: 80%;">3.50</span></div>
                        <div class="price"><del><span class="amount">140.00</span></del><ins><span class="amount"><?php echo $p['amount'];?></span></ins></div>
                      </div>
                    </div>
                   </div>
                   <?php

}
?>
     

                 
                    </div>
                 
                  </div>
           </div>
              </div>
            </div>
   
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  <?php

 include "footer.php";
?>
 