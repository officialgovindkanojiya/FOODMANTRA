<?php

include "header.php";
include "connection.php";

$email=$_SESSION['session2'];

?>
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">REGISTER NOW</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-push-2">
            <div class="widget border-1px p-30">
              <h5 class="widget-title line-bottom">Register Now</h5>
              <form  action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                 <select name="state" class="form-control">
                   <option>--State--</option>
                   <option value="up">Uttar Pradesh</option>
                   <option value="mumbai">Mumbai</option>
                 </select>
                </div>
                <div class="form-group">
                 <select name="city" class="form-control">
                   <option>--City--</option>
                   <option value="ayodhya">Ayodhya</option>
                   <option value="lko">Lucknow</option>
                 </select>
                </div>

                <div class="form-group">
                  <input name="pin" class="form-control" type="text" required="" placeholder="Enter Pin">
                </div>
                <div class="form-group">
                  <textarea name="address" id="" cols="30" rows="1"  class="form-control" placeholder="Address"></textarea>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-primary"   class="form-control"   required="" value="Register">
                </div>
                
              </form>

              
            </div>
          </div>
        </div>
      </div>
    </section> 
  </div>  
<?php
if($_POST)
{
  extract($_POST);
  
    $checkpin=preg_match("/^[0-9]{6,6}$/",$pin);
    if($checkpin){
    mysqli_query($conn,"INSERT INTO hotelregister2 VALUES('','$email','$state','$city','$pin','$address')");
    echo("<script>alert('Successfully Registered');</script>");
    echo("<script>location.href ='login1.php';</script>");
    }
    else{
      echo("<script>alert('Invaild Credentials!!');</script>");

    }
  }


?>
<?php
include "footer.php";
?>