<?php

include "header.php";
include "connection.php";
?>
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/bg/bg6.jpg">
      <div class="container pt-70 pb-20">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">REGISTER NOW</h2>
               
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-push-2">
            <div class="widget border-1px p-30">
              <h5 class="widget-title line-bottom">Register Now</h5>
              <form  action="" method="post" enctype="multipart/form-data">
              <div class="form-group">
                  <input name="ownername" class="form-control" type="text" required="" placeholder="Enter Name">
                </div>
                <div class="form-group">
                  <input name="hotelname" class="form-control" type="text" required="" placeholder="Enter Hotel Name">
                </div>
              <div class="form-group">
                  <input name="phone" class="form-control" type="text" required="" placeholder="Enter Phone">
                </div>
              <div class="form-group">
                  <input name="email" class="form-control" type="email" required="" placeholder="Enter Email">
                </div>

                <div class="form-group">
                  <input name="pass" class="form-control" type="password" required="" placeholder="Enter Password">
                </div>  
                <div class="form-group">
                  <input type="submit" class="btn btn-primary"   class="form-control"   required="" value="Next">
                </div>
                
              </form>

              
            </div>
          </div>
        </div>
      </div>
    </section> 
  </div>  

<?php
if($_POST)
{
  extract($_POST);
  $checkname=preg_match("/^[a-zA-Z]{3,20}$/",$ownername);
  $checkphone=preg_match("/^[0-9]{10,10}$/",$phone);
  $checkemail=filter_var($email,FILTER_VALIDATE_EMAIL);
  // $checkemail=filter_var($email,FILTER_VALIDATE_EMAIL);
  if($checkname && $checkphone)
  {
     
    $_SESSION['session2']=$email;

    $query=mysqli_query($conn,"SELECT * FROM hotelregister1 WHERE email='$email'");
    if(mysqli_num_rows($query)==1)
    {
      echo "<script>alert('Email is already Registered');</script>";
    }
    else{

    mysqli_query($conn,"INSERT INTO hotelregister1 VALUES('','$ownername','$hotelname','$phone','$email','$pass')");
    

    echo("<script>location.href ='hotel_register2.php';</script>");
    }
    
  }
  else{
    echo "<script>alert('Invalid Credentials!!');</script>";
  }
}

?>
<?php
include "footer.php";
?>